export const DOCS_BLOCK_SCHEMAS = {
    accordion: { fields: [{ name: 'items', type: 'array' }] },
    tabs: { fields: [{ name: 'items', type: 'array' }] },
    table: { fields: [{ name: 'rows', type: 'array' }] },
    callout: { fields: [{ name: 'kind', type: 'string' }, { name: 'content', type: 'array' }] },
    code: { fields: [{ name: 'value', type: 'string' }] },
    docImage: { fields: [{ name: 'url', type: 'string' }] },
    embed: { fields: [{ name: 'src', type: 'string' }] },
    math: { fields: [{ name: 'code', type: 'string' }] },
    nodes: { fields: [{ name: 'nodes', type: 'array' }] },
    raw: { fields: [{ name: 'markdown', type: 'string' }] },
    tsDocs: { fields: [{ name: 'scope', type: 'string' }] },
};
export const PROBLEM_BLOCK_TYPES = ['hint', 'headline', 'nodes', 'entity', 'definition', 'countryReference', 'notes', 'photo', 'audio', 'video', 'choicesReference', 'question', 'prompts', 'timer', 'table', 'map', 'tabs', 'accordion'];
export const TERRA_CONTAINER_TYPES = ['tabs', 'accordion', 'callout'];
export const ARTICLE_INLINE_SCHEMAS = {};
export const PROBLEM_BLOCK_SCHEMAS = {};
//# sourceMappingURL=types.js.map