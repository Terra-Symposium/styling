import type { DocsActionOperation, DocsActionResult } from '../../host.js';
export declare function configureDocsActionProxy(handler: <T = unknown>(operation: DocsActionOperation, input?: unknown) => Promise<DocsActionResult<T>>): void;
/** Internal compatibility bridge for the original UI's nested host-action calls. */
export declare const actions: Record<string, any>;
//# sourceMappingURL=action-proxy.d.ts.map