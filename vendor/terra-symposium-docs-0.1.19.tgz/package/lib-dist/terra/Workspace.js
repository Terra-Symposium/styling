import { jsx as _jsx } from "react/jsx-runtime";
import Scaffold from './pages/docs/_main.js';
import { configureDocsHost } from '../host-runtime.js';
/** The source-preserving shared Terra Docs workspace used by host route adapters. */
export function TerraDocsWorkspace(props) {
    configureDocsHost(props.host, props.customBlocks);
    return _jsx(Scaffold, { tree: props.tree, pathname: props.pathname, permission: props.permission, userData: props.userData ?? null, title: props.title, ...(props.path ? { path: props.path } : {}), ...(props.description ? { description: props.description } : {}), ...(props.contributors ? { contributors: props.contributors } : {}), ...(props.updatedAt ? { updatedAt: props.updatedAt } : {}), ...(props.source ? { source: props.source } : {}), ...(props.content !== undefined ? { content: props.content } : {}), ...(props.standalone !== undefined ? { standalone: props.standalone } : {}), ...(props.full !== undefined ? { full: props.full } : {}), ...(props.mode ? { mode: props.mode } : {}) });
}
//# sourceMappingURL=Workspace.js.map