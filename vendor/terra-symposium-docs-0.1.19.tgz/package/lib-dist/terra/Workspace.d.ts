import type { JSX } from 'react';
import type { TerraDocsWorkspaceProps } from '../host.js';
/** The source-preserving shared Terra Docs workspace used by host route adapters. */
export declare function TerraDocsWorkspace(props: TerraDocsWorkspaceProps): JSX.Element;
//# sourceMappingURL=Workspace.d.ts.map