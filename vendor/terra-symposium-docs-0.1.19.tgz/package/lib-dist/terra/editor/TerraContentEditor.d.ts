import type { JSX } from 'react';
/** Docs-only Portable Text profile extracted from the website's shared editor. */
export declare function TerraContentEditor({ content, onChange, readOnly, resetKey }: {
    content?: any[];
    onChange?: (content: any[]) => void;
    readOnly?: boolean;
    resetKey?: string;
    [key: string]: any;
}): JSX.Element;
//# sourceMappingURL=TerraContentEditor.d.ts.map