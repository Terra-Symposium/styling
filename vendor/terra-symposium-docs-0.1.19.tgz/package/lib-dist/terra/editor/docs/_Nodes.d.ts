/**
 * astro/src/components/editor/docs/_Nodes.tsx
 */
import type { DocsBlock } from '../types.js';
/**
 * Renders the nodes block component.
 *
 * @param props - Portable Text node props passed to the renderer.
 *
 * @return Rendered documentation node content.
 */
export declare function NodesBlock({ block }: {
    block: DocsBlock<'nodes'>;
}): JSX.Element;
//# sourceMappingURL=_Nodes.d.ts.map