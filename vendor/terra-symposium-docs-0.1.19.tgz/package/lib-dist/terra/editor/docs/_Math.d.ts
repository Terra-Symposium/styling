/**
 * astro/src/components/editor/docs/_Math.tsx
 * Docs math renderer with optional editing controls.
 */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Sanity Portable Text math expression block fields. */
type MathBlockData = DocsBlock<'math'>;
/**
 * Renders the formula display and, when supplied, its edit popover.
 *
 * @param props - Math source, inline or block mode, optional class name, and callback for updating authored source.
 *
 * @return The formatted math expression or editable math control.
 */
export declare function renderMath({ code, inline, className, write }: {
    code: string;
    inline?: boolean;
    className?: string;
    write?: (code: string, inline?: boolean) => void;
}): JSX.Element;
/** Adapts Portable Text's block-object contract to the math renderer. */
/**
 * Renders the renderMathBlock component.
 *
 * @param props - Portable Text renderer attributes, nested children, math node, path, and read-only mode.
 *
 * @return The math block renderer in editable or read-only mode.
 */
export declare function renderMathBlock({ attributes: attrs, children, node, path, readOnly }: PortableTextBlockRendererProps<MathBlockData>): JSX.Element;
export {};
//# sourceMappingURL=_Math.d.ts.map