import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/** Docs callout renderer with view and edit modes. */
import { useEditor } from '@portabletext/editor';
import { TerraContentEditor } from '../TerraContentEditor.js';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Input } from '@terra-symposium/styling/ui/terra-original';
/** Renders a Docs callout and its nested rich-text body.
 *
 * @param props - Portable Text block and editor attributes for the authored callout title, style, and content.
 * @returns The rendered callout block.
 */
function Callout({ block }) {
    return (_jsx(ErrorBoundary, { name: 'CalloutBlock', children: _jsxs("aside", { className: 'docs-block my-0 flow-root [&>:first-child]:!mt-0 [&>:last-child]:!mb-0', "data-docs-aside": block.kind ?? 'note', children: [_jsx("h4", { className: 'title', children: block.title ?? block.kind ?? 'Note' }), _jsx(TerraContentEditor, { content: (block.content ?? []), docsAttachments: [], memberProfile: 'docs', nested: true, readOnly: true })] }) }));
}
Object.assign(Callout, { displayName: 'DocsCalloutPreview' });
/** Renders editable Docs callout controls and nested content. */
/**
 * Renders the CalloutEditor component.
 *
 * @param props - Portable Text editor attributes, nested children, block node, and path used to edit a callout.
 * @returns The editable callout and nested rich-text surface.
 */
function CalloutEditor({ attributes: attrs, children, node, path }) {
    const editor = useEditor();
    const block = node;
    return (_jsx(ErrorBoundary, { name: 'CalloutEditor', children: _jsxs("aside", { ...attrs, contentEditable: false, className: 'docs-block my-0 flow-root rounded-md border border-primary-5 p-4', "data-terra-block": 'callout', "data-docs-aside": block.kind ?? 'note', children: [_jsx(Input, { "aria-label": 'Callout title', className: 'mb-3 border-0 bg-transparent px-0 text-lg font-bold shadow-none', value: block.title ?? block.kind ?? 'Note', onChange: e => editor.send({ type: 'block.set', at: path, props: { title: e.currentTarget.value } }) }), _jsx(TerraContentEditor, { content: (block.content ?? []), docsAttachments: [], memberProfile: 'docs', nested: true, onChange: c => editor.send({ type: 'block.set', at: path, props: { content: c } }) }), children] }) }));
}
Object.assign(CalloutEditor, { displayName: 'DocsCalloutEditor' });
/** Adapts Portable Text's block-object contract to the callout renderer. */
/**
 * Renders the renderCallout component.
 *
 * @param props - Portable Text renderer attributes, nested children, callout node, path, and read-only mode.
 * @returns The callout renderer in editable or read-only mode.
 */
export function renderCallout({ attributes: attrs, children, node, path, readOnly }) {
    return readOnly ? _jsx(Callout, { block: node }) : _jsx(CalloutEditor, { attributes: attrs, children: children, node: node, path: path });
}
Object.assign(renderCallout, { displayName: 'DocsCalloutRenderer' });
//# sourceMappingURL=_Callout.js.map