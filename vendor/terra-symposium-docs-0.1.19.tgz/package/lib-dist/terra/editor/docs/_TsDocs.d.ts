/**
 * astro/src/components/editor/docs/_TsDocs.tsx
 */
import type { DocsBlock } from '../types.js';
/**
 * Renders the ts docs component.
 *
 * @param props - TypeScript documentation block data and rendering props.
 *
 * @return Rendered TypeScript documentation content.
 */
export declare function TsDocs({ block }: {
    block: DocsBlock<'tsDocs'>;
}): React.JSX.Element | null;
//# sourceMappingURL=_TsDocs.d.ts.map