import type { DocsHostTreeNode } from './host.js';
import type { DocsLocalPage } from './LocalDocsWorkspace.js';
export declare const docsPages: DocsLocalPage[];
export declare const docsTree: DocsHostTreeNode[];
//# sourceMappingURL=docs-catalog.d.ts.map