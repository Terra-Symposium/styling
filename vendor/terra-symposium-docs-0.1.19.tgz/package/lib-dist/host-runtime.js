import { configureDocsActionProxy } from './terra/runtime/action-proxy.js';
import { setDocsCustomComponents } from './terra/pages/docs/_custom.js';
let activeHost;
export function getDocsHostAdapter() { return activeHost; }
/** Install host-owned storage and capability checks before mounting the Docs surface. */
export function configureDocsHost(host, customBlocks = []) {
    activeHost = host;
    setDocsCustomComponents(customBlocks);
    configureDocsActionProxy(async (operation, input) => {
        if (operation.startsWith('write.') && !host.capabilities.write)
            return { error: new Error('This Docs instance is read-only.') };
        if (operation.startsWith('write.attachment.') && !host.capabilities.attachments)
            return { error: new Error('Attachment changes are disabled for this Docs instance.') };
        if (operation.startsWith('write.doc.reorder') && !host.capabilities.reorder)
            return { error: new Error('Reordering is disabled for this Docs instance.') };
        if (operation.includes('.versions.') && !host.capabilities.history)
            return { error: new Error('History is disabled for this Docs instance.') };
        return host.invoke(operation, input);
    });
}
//# sourceMappingURL=host-runtime.js.map