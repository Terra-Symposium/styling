import type { JSX } from 'react';
/** The portable Docs members. A host can disable any member without changing stored data. */
export declare const DOCS_BLOCK_TYPES: readonly ["accordion", "tabs", "table", "callout", "code", "docImage", "embed", "math", "nodes", "raw", "tsDocs"];
export type DocsBlockType = (typeof DOCS_BLOCK_TYPES)[number];
export type DocsBlockOptions = Partial<Record<DocsBlockType | 'inlineMath', boolean>>;
export type RichBlock = {
    _type: string;
    _key?: string;
    markdown?: string;
    [key: string]: unknown;
};
export declare function enabledDocsBlocks(options?: DocsBlockOptions): DocsBlockType[];
export declare const DOCS_BLOCK_FIELDS: Record<DocsBlockType, {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'array' | 'object';
}[]>;
export declare function defaultDocsBlock(type: DocsBlockType): RichBlock;
/** Read-only rendering for every reusable Terra Docs member. Unknown data stays in the value. */
export declare function DocsRichBlock({ block }: {
    block: RichBlock;
}): JSX.Element;
export declare function docsBlockNodes(options?: DocsBlockOptions): import("@portabletext/editor").BlockObject[];
//# sourceMappingURL=blocks.d.ts.map