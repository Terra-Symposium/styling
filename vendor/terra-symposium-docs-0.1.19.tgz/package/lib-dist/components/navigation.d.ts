import type { JSX } from 'react';
export type DocsNavNode = {
    id?: string;
    path?: string;
    title: string;
    href?: string;
    description?: string;
    updatedAt?: string;
    attachments?: import('./workspace.js').DocsAttachment[];
    children?: DocsNavNode[];
};
export declare function DocsNavigation({ nodes, currentPath, hue, }: {
    nodes: DocsNavNode[];
    currentPath: string;
    hue?: number | null;
}): JSX.Element;
//# sourceMappingURL=navigation.d.ts.map