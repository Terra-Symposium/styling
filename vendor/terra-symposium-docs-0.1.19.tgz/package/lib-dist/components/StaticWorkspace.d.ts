import type { DocsAttachment, DocsSection } from './workspace.js';
import type { DocsNavNode } from './navigation.js';
import type { JSX } from 'react';
type Props = {
    title: string;
    homeHref?: string;
    description?: string;
    pageTitle?: string;
    hue?: number | null;
    nodes?: DocsNavNode[];
    sections?: DocsSection[];
    currentPath: string;
    rootPath?: string;
    markdown?: string;
    content?: unknown;
    attachments?: DocsAttachment[];
    updatedAt?: string;
};
/** Adapts a host's local Markdown pages to the original, read-only Terra Docs workspace. */
export declare function DocsStaticWorkspace({ title, homeHref, description, pageTitle, hue, nodes, sections, currentPath, rootPath, markdown, content, attachments, updatedAt, }: Props): JSX.Element;
export {};
//# sourceMappingURL=StaticWorkspace.d.ts.map