import type { DocsSection, DocsAttachment, DocsCapabilities, DocsRemoteProvider, DocsTreeActions, DocsMode as WorkspaceMode } from './workspace.js';
import type { DocsNavNode } from './navigation.js';
import type { JSX, ReactNode } from 'react';
/** Shared Terra Docs page shell for independent installations and repository guides. */
export declare function DocsSiteLayout({ title, homeHref, description, pageTitle, nodes, currentPath, hue, children, sidebarContent, sections, attachments, rootPath, markdown, content, capabilities, onEdit, onSave, onHistory, onPublish, remoteProvider, onModeChange, onUpload, treeActions, }: {
    title: string;
    homeHref?: string;
    description?: string;
    pageTitle?: string;
    nodes: DocsNavNode[];
    currentPath: string;
    hue?: number | null;
    children?: ReactNode;
    sidebarContent?: ReactNode;
    sections?: DocsSection[];
    attachments?: DocsAttachment[];
    rootPath?: string;
    markdown?: string;
    content?: unknown;
    capabilities?: DocsCapabilities;
    onEdit?: () => void;
    onSave?: () => void;
    onHistory?: () => void;
    onPublish?: () => void;
    remoteProvider?: DocsRemoteProvider;
    onModeChange?: (mode: WorkspaceMode) => void;
    onUpload?: (file: File) => void | Promise<void>;
    treeActions?: DocsTreeActions;
}): JSX.Element;
//# sourceMappingURL=SiteLayout.d.ts.map