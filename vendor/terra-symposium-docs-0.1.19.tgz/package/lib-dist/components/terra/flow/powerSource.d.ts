/**
 * astro/src/components/flow/powerSource.ts
 * Power Source graph placement and route presentation.
 */
import type { PowerSrcGraph } from '../runtime/types.js';
import type { StructureQuestion } from '../runtime/types.js';
/**
 * Handles with power source positions.
 *
 * @param graph - Power Source graph whose content nodes need positions.
 * @param questions - Questions used to resolve node titles by document id.
 *
 * @return Graph with deterministic row positions for its content and terminal nodes.
 */
export declare function withPowerSrcPositions(graph: PowerSrcGraph, questions: StructureQuestion[]): PowerSrcGraph;
//# sourceMappingURL=powerSource.d.ts.map