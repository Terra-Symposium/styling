// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/flow/_layout.ts
 * Pure Dagre layout primitives shared by flow UI and testable graph helpers.
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// COMPONENTS
import Dagre from '@dagrejs/dagre';
/*//////////////////////////////////////////////////
EXPORTS
//////////////////////////////////////////////////*/
/**
 * Handles layout graph.
 *
 * @param nodes - Nodes to position in the generated graph.
 * @param edges - Directed connections between graph nodes.
 * @param direction - Dagre rank direction used for layout.
 * @param nodeSep - Minimum separation between adjacent nodes.
 * @param rankSep - Minimum separation between graph ranks.
 * @param opts - Callbacks for measuring, registering, and placing nodes.
 *
 * @return Positioned nodes and the computed graph height.
 */
export function layoutGraph(nodes, edges, direction, nodeSep, rankSep, opts) {
    const graph = new Dagre.graphlib.Graph({ compound: true });
    graph.setGraph({ rankdir: direction, nodesep: nodeSep, ranksep: rankSep });
    graph.setDefaultEdgeLabel(() => ({}));
    nodes.forEach((n) => {
        const size = opts.getSize(n);
        if (opts.registerNode)
            opts.registerNode(graph, n, size);
        else
            graph.setNode(n.id, { width: size.w, height: size.h });
    });
    nodes.forEach((n) => {
        const parentId = opts.getGroupId?.(n);
        if (parentId && graph.hasNode(parentId))
            graph.setParent(n.id, parentId);
    });
    edges.forEach((e) => graph.setEdge(e.source, e.target));
    Dagre.layout(graph);
    return {
        positionedNodes: nodes.map((n) => {
            const persisted = opts.getCustomPosition?.(n);
            const dagreNode = graph.node(n.id);
            return opts.placeNode
                ? opts.placeNode(n, dagreNode, persisted)
                : { ...n, position: persisted ?? { x: dagreNode?.x ?? 0, y: dagreNode?.y ?? 0 } };
        }),
        graphHeight: graph.graph().height ?? 0,
    };
}
//# sourceMappingURL=_layout.js.map