/**
 * Indicates whether the active menu context is expected to resolve to a graph node.
 *
 * @param ctx - Active context-menu target.
 * @returns Whether the context identifies a node whose lock state should be resolved.
 */
export function shouldResolveNodeMenuTarget(ctx) {
    return ctx.type === '_node' && ctx.id !== null;
}
//# sourceMappingURL=menuContext.js.map