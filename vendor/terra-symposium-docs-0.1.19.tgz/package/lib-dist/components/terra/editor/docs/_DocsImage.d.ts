/**
 * astro/src/components/editor/docs/_DocsImage.tsx
 * Docs image renderer with view and edit modes.
 */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Sanity Portable Text image fields authored in documentation content. */
type DocsImgBlock = DocsBlock<'docImage'>;
/** Adapts Portable Text's block-object contract to the image renderer. */
/**
 * Renders the renderImage component.
 *
 * @param props - Portable Text renderer attributes, nested children, image node, path, and read-only mode.
 *
 * @return The image renderer in editable or read-only mode.
 */
export declare function renderImage({ attributes: attrs, children, node, path, readOnly, }: PortableTextBlockRendererProps<DocsImgBlock>): JSX.Element;
export {};
//# sourceMappingURL=_DocsImage.d.ts.map