import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_DocsImage.tsx
 * Docs image renderer with view and edit modes.
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// API
import { useEditor } from '@portabletext/editor';
// COMPONENTS
import { AlertError } from '@terra-symposium/styling/ui/terra-original';
import { Button } from '@terra-symposium/styling/ui/terra-original';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Empty } from '../../runtime/ui.js';
import { Image as ImageIcon, TrashCan as TrashIcon } from '@carbon/icons-react';
import { Input } from '@terra-symposium/styling/ui/terra-original';
const FIELD_LABEL = 'block text-sm font-medium text-primary-12';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/**
 * Renders a Docs image block from its authored block.
 *
 * @param props - Authored image block containing the source URL, dimensions, and accessibility metadata.
 *
 * @return The image with its authored caption and alternate text.
 */
function Img({ block }) {
    if (!block.url)
        return (_jsx(ErrorBoundary, { name: "Image", children: _jsx(AlertError, { title: "Image unavailable", description: "This image block has no URL." }) }));
    return (_jsx(ErrorBoundary, { name: "Image", children: _jsx("img", { src: block.url, alt: block.alt ?? '', className: "max-w-full", ...(block.title === undefined ? {} : { title: block.title }), ...(block.width === undefined ? {} : { width: block.width }), ...(block.height === undefined ? {} : { height: block.height }) }) }));
}
Object.assign(Img, { displayName: 'DocsImagePreview' });
/** Adapts Portable Text's block-object contract to the image renderer. */
/**
 * Renders the renderImage component.
 *
 * @param props - Portable Text renderer attributes, nested children, image node, path, and read-only mode.
 *
 * @return The image renderer in editable or read-only mode.
 */
export function renderImage({ attributes: attrs, children, node, path, readOnly, }) {
    return readOnly ? (_jsx(Img, { block: node })) : (_jsx(ImgEditor, { attributes: attrs, children: children, node: node, path: path }));
}
Object.assign(renderImage, { displayName: 'DocsImageRenderer' });
/** Connects the image block's local controls to its Portable Text state. */
/**
 * Renders the ImageEditor component.
 *
 * @param props - Portable Text editor attributes, nested children, image node, and path used to update image metadata.
 *
 * @return The editable image block controls.
 */
function ImgEditor({ attributes: attrs, children, node, path, }) {
    const editor = useEditor();
    const update = (field, val) => editor.send({ type: 'block.set', at: path, props: { [field]: val } });
    return (_jsx(ErrorBoundary, { name: "ImageBlock", children: _jsxs("section", { ...attrs, contentEditable: false, className: "my-8 rounded-xl border border-secondary-6 bg-secondary-1/40 p-4 shadow-sm sm:p-5", "data-terra-block": "docImage", children: [_jsxs("div", { className: "flex items-center gap-3 border-b border-secondary-5 pb-3 text-primary-12", children: [_jsx("span", { className: "flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary-3 text-secondary-11", children: _jsx(ImageIcon, { className: "size-5", "aria-hidden": "true" }) }), _jsxs("div", { children: [_jsx("h3", { className: "font-semibold", children: "Image" }), _jsx("p", { className: "text-sm text-primary-11", children: "Docs image block" })] })] }), _jsxs("label", { className: `mt-4 ${FIELD_LABEL}`, children: [_jsx("span", { children: "Image URL" }), _jsx(Input, { className: "mt-1.5", type: "url", value: node.url ?? '', onChange: (e) => update('url', e.currentTarget.value), placeholder: "https://example.com/image.png" })] }), node.url ? (_jsxs("figure", { className: "mt-4 overflow-hidden rounded-lg border border-secondary-5 bg-primary-1", children: [_jsx("img", { src: node.url, alt: node.alt ?? '', title: node.title ?? undefined, className: "max-h-[32rem] w-full object-contain", ...(node.width ? { width: node.width } : {}), ...(node.height ? { height: node.height } : {}) }), node.title ? (_jsx("figcaption", { className: "border-t border-secondary-5 px-3 py-2 text-sm text-primary-11", children: node.title })) : null] })) : (_jsx(Empty, { variant: "preview", children: "Add an image URL to preview it here." })), _jsxs("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [_jsxs("label", { className: FIELD_LABEL, children: [_jsx("span", { children: "Alternative text" }), _jsx(Input, { className: "mt-1.5", value: node.alt ?? '', onChange: (e) => update('alt', e.currentTarget.value), placeholder: "Describe the image" })] }), _jsxs("label", { className: FIELD_LABEL, children: [_jsx("span", { children: "Caption" }), _jsx(Input, { className: "mt-1.5", value: node.title ?? '', onChange: (e) => update('title', e.currentTarget.value), placeholder: "Optional caption" })] })] }), _jsxs("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [_jsxs("label", { className: FIELD_LABEL, children: [_jsx("span", { children: "Width" }), _jsx(Input, { className: "mt-1.5", value: node.width ?? '', onChange: (e) => update('width', e.currentTarget.value), placeholder: "e.g. 640px" })] }), _jsxs("label", { className: FIELD_LABEL, children: [_jsx("span", { children: "Height" }), _jsx(Input, { className: "mt-1.5", value: node.height ?? '', onChange: (e) => update('height', e.currentTarget.value), placeholder: "e.g. auto" })] })] }), _jsx("p", { className: "mt-3 text-xs leading-5 text-primary-10", children: "Use a stable, publicly accessible image URL. Uploading assets is part of real-content integration." }), _jsxs(Button, { className: "mt-4", size: "sm", variant: "destructive", onClick: () => editor.send({ type: 'unset', at: path }), children: [_jsx(TrashIcon, { "aria-hidden": "true" }), " Delete image"] }), children] }) }));
}
Object.assign(ImgEditor, { displayName: 'DocsImageEditor' });
//# sourceMappingURL=_DocsImage.js.map