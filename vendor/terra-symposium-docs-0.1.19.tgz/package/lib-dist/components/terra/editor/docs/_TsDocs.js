import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_TsDocs.tsx
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// API
import { actions } from '../../runtime/action-proxy.js';
import { cn } from '../../runtime/runtime.js';
import { useEffect, useState } from 'react';
// COMPONENTS
import { AlertError } from '@terra-symposium/styling/ui/terra-original';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Empty } from '../../runtime/ui.js';
import { TerraContentEditor } from '../TerraContentEditor.js';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/** Loads and renders TypeScript documentation for a selected scope. */
/**
 * Renders the TsDocsRenderer component.
 *
 * @param props - Optional API documentation scope and styling class used to load the reference panel.
 *
 * @return The API reference panel, or `null` when no scope is selected.
 */
function TsDocsRenderer({ scope, className, }) {
    const [items, setItems] = useState(null);
    const [err, setErr] = useState(null);
    useEffect(() => {
        if (!scope)
            return;
        let a = true;
        actions.read
            .tsdocs({ scope })
            .then(async ({ data: d, error: e, }) => {
            if (e || !d?.docs)
                throw e || new Error('Failed to fetch tsdocs');
            const docs = [];
            for (const entry of d.docs) {
                const { data: body, error: bodyErr } = await actions.read.source.body({
                    source: entry.body,
                });
                if (bodyErr || !body)
                    throw bodyErr || new Error(`Failed to parse ${entry.slug}`);
                docs.push({ slug: entry.slug, title: entry.title, body });
            }
            if (a)
                setItems(docs);
        })
            .catch((e) => {
            if (a)
                setErr(e instanceof Error ? e.message : 'Failed to fetch tsdocs');
        });
        return () => {
            a = false;
        };
    }, [scope]);
    if (!scope)
        return null;
    if (err)
        return (_jsx(ErrorBoundary, { name: "TsDocsRenderer", children: _jsx(AlertError, { title: "TsDocs Error", description: err }) }));
    if (!items)
        return (_jsx(ErrorBoundary, { name: "TsDocsRenderer", children: _jsx("div", { className: "h-24 w-full animate-pulse rounded-sm bg-primary-3", "data-docs-block-skeleton": true }) }));
    if (items.length === 0)
        return (_jsx(ErrorBoundary, { name: "TsDocsRenderer", children: _jsxs(Empty, { children: ["No tsdocs found for ", _jsx("code", { children: scope }), "."] }) }));
    return (_jsx(ErrorBoundary, { name: "TsDocsRenderer", children: _jsxs("div", { className: cn('tsdocs-wrapper max-w-none space-y-10', className), children: [items.length > 1 && (_jsx("nav", { "aria-label": "TSDocs contents", children: _jsx("ul", { className: "m-0 list-none p-0", children: items.map((d) => (_jsx("li", { children: _jsx("a", { href: `#${d.slug.replaceAll('/', '-')}`, className: "text-primary-9 hover:underline", children: d.title }) }, d.slug))) }) })), items.map((d) => (_jsxs("section", { id: d.slug.replaceAll('/', '-'), children: [items.length > 1 && _jsx("h2", { children: d.title }), _jsx(TerraContentEditor, { content: d.body, docsAttachments: [], memberProfile: "docs", nested: true, readOnly: true })] }, d.slug)))] }) }));
}
Object.assign(TsDocsRenderer, { displayName: 'TsDocsRenderer' });
/**
 * Renders the ts docs component.
 *
 * @param props - TypeScript documentation block data and rendering props.
 *
 * @return Rendered TypeScript documentation content.
 */
export function TsDocs({ block, }) {
    return (_jsx(ErrorBoundary, { name: "TsDocs", children: _jsx(TsDocsRenderer, { ...(block.scope === undefined ? {} : { scope: block.scope }) }) }));
}
Object.assign(TsDocs, { displayName: 'TsDocs' });
//# sourceMappingURL=_TsDocs.js.map