import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/** Docs table renderer with view and edit modes. */
import { useEditor } from '@portabletext/editor';
import { Add as AddIcon, TrashCan as TrashIcon } from '@carbon/icons-react';
import { TerraContentEditor } from '../TerraContentEditor.js';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Button } from '@terra-symposium/styling/ui/terra-original';
import { Input } from '@terra-symposium/styling/ui/terra-original';
import { isRec } from '../../runtime/runtime.js';
const key = (val, fallback) => isRec(val) && typeof val._key === 'string' ? val._key : fallback;
const cells = (vals, count) => Array.from({ length: count }, (_cell, i) => vals[i]);
const newKey = () => crypto.randomUUID().replaceAll('-', '');
const cell = (text = '') => ({
    _key: newKey(),
    _type: 'cell',
    content: text
        ? [
            {
                _key: newKey(),
                _type: 'block',
                children: [{ _key: newKey(), _type: 'span', marks: [], text }],
                markDefs: [],
                style: 'normal',
            },
        ]
        : [],
});
/** Renders a Docs table and its nested cell content.
 *
 * @param props - Authored table block with its headers, rows, and cell content.
 * @returns The accessible table view.
 */
function Table({ block }) {
    const rows = (block.rows ?? []);
    const count = rows.reduce((m, r) => Math.max(m, Array.isArray(r.cells) ? r.cells.length : 0), 0);
    const renderCell = (c) => c ? (_jsx(TerraContentEditor, { content: (Array.isArray(c.content) ? c.content : []), docsAttachments: [], memberProfile: "docs", nested: true, readOnly: true })) : null;
    return (_jsx(ErrorBoundary, { name: "TableBlock", children: _jsxs("section", { className: "my-6 overflow-x-auto", "data-docs-editor-block": "DocsTable", children: [block.header && block.header !== 'Table' && _jsx("h3", { className: "sr-only", children: block.header }), _jsxs("table", { children: [_jsx("thead", { children: _jsx("tr", { children: cells(Array.isArray(rows[0]?.cells) ? rows[0].cells : [], count).map((c, i) => (_jsx("th", { children: renderCell(c) }, c ? key(c, `${i}`) : i))) }) }), _jsx("tbody", { children: rows.slice(1).map((r, v) => {
                                return (_jsx("tr", { children: cells(Array.isArray(r.cells) ? r.cells : [], count).map((c, i) => (_jsx("td", { children: renderCell(c) }, c ? key(c, `${i}`) : i))) }, key(r, `${v}`)));
                            }) })] })] }) }));
}
Object.assign(Table, { displayName: 'DocsTablePreview' });
/** Renders editable Docs table controls and cells.
 *
 * @param props - Portable Text editor attributes, nested children, table node, and path used to update rows and cells.
 * @returns The editable table controls and cells.
 */
function TableEditor({ attributes: attrs, children, node, path, }) {
    const editor = useEditor();
    const block = node;
    const rows = block.rows ?? [];
    const colCount = Math.max(1, ...rows.map((r) => r.cells?.length ?? 0));
    const update = (nRows) => editor.send({ type: 'block.set', at: path, props: { rows: nRows } });
    return (_jsx(ErrorBoundary, { name: "TableEditor", children: _jsxs("section", { ...attrs, contentEditable: false, className: "my-6 overflow-x-auto rounded-md border border-primary-5 p-3", "data-terra-block": "table", children: [_jsxs("div", { className: "mb-3 flex flex-wrap items-center gap-2", children: [_jsx(Input, { "aria-label": "Table heading", className: "max-w-sm", value: block.header ?? '', onChange: (e) => editor.send({ type: 'block.set', at: path, props: { header: e.currentTarget.value } }), placeholder: "Table heading" }), _jsxs(Button, { size: "sm", variant: "outline", onClick: () => update([
                                ...rows,
                                {
                                    _key: newKey(),
                                    _type: 'row',
                                    cells: Array.from({ length: colCount }, () => cell()),
                                },
                            ]), children: [_jsx(AddIcon, { "aria-hidden": "true" }), " Row"] }), _jsxs(Button, { size: "sm", variant: "outline", onClick: () => update(rows.map((r) => ({ ...r, cells: [...(r.cells ?? []), cell()] }))), children: [_jsx(AddIcon, { "aria-hidden": "true" }), " Column"] })] }), _jsx("table", { className: "w-full border-collapse text-left", children: _jsx("tbody", { children: rows.map((r, v) => (_jsxs("tr", { children: [Array.from({ length: colCount }, (_cell, i) => {
                                    const Tag = i === 0 ? 'th' : 'td';
                                    return (_jsx(Tag, { className: "border border-primary-5 p-1 align-top", children: _jsx("textarea", { "aria-label": `Table cell ${v + 1}, ${i + 1}`, className: "min-h-10 w-full resize-y bg-transparent p-1 outline-none", value: ((c) => {
                                                return Array.isArray(c?.content)
                                                    ? c.content
                                                        .map((b) => Array.isArray(b.children)
                                                        ? b.children
                                                            .map((c) => 'text' in c && typeof c.text === 'string' ? c.text : '')
                                                            .join('')
                                                        : '')
                                                        .join('\n')
                                                    : '';
                                            })(r.cells?.[i]), onChange: ({ currentTarget: { value: text } }) => {
                                                update(rows.map((r, c) => ({
                                                    ...r,
                                                    cells: Array.from({ length: colCount }, (_cell, x) => {
                                                        const curr = r.cells?.[x] ?? cell();
                                                        return c === v && x === i
                                                            ? { ...curr, content: cell(text).content }
                                                            : curr;
                                                    }),
                                                })));
                                            } }) }, r.cells?.[i]?._key ?? i));
                                }), _jsx("td", { className: "w-9 p-1", children: _jsx(Button, { "aria-label": `Delete row ${v + 1}`, size: "icon", variant: "ghost", onClick: () => update(rows.filter((_row, i) => i !== v)), children: _jsx(TrashIcon, { "aria-hidden": "true" }) }) })] }, r._key))) }) }), colCount > 1 && (_jsx("div", { className: "mt-2 flex gap-1", children: Array.from({ length: colCount }, (_cell, v) => (_jsxs(Button, { size: "xs", variant: "ghost", onClick: () => update(rows.map((r) => ({
                            ...r,
                            cells: (r.cells ?? []).filter((_cell, i) => i !== v),
                        }))), children: ["Delete column ", v + 1] }, v))) })), children] }) }));
}
Object.assign(TableEditor, { displayName: 'DocsTableEditor' });
/** Adapts Portable Text's block-object contract to the table renderer.
 *
 * @param props - Portable Text renderer attributes, nested children, table node, path, and read-only mode.
 * @returns The table renderer in editable or read-only mode.
 */
export function renderTable({ attributes: attrs, children, node, path, readOnly, }) {
    return readOnly ? (_jsx(Table, { block: node })) : (_jsx(TableEditor, { attributes: attrs, children: children, node: node, path: path }));
}
Object.assign(renderTable, { displayName: 'DocsTableRenderer' });
//# sourceMappingURL=_Table.js.map