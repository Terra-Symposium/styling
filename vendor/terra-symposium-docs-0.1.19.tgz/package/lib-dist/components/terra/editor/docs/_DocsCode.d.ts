/** Docs code block renderer with view and edit modes. */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Sanity Portable Text code-block fields used by the docs editor. */
type CodeBlockData = DocsBlock<'code'>;
/** Adapts Portable Text's block-object contract to the code renderer. */
/**
 * Renders the renderCode component.
 *
 * @param props - Portable Text renderer attributes, nested children, code block node, path, and read-only mode.
 * @returns The code block renderer in editable or read-only mode.
 */
export declare function renderCode({ attributes: attrs, children, node, path, readOnly, }: PortableTextBlockRendererProps<CodeBlockData>): JSX.Element;
export {};
//# sourceMappingURL=_DocsCode.d.ts.map