/**
 * astro/src/components/editor/docs/_CodeBlock.tsx
 * Shared Docs CodeMirror renderer.
 */
import type { JSX } from 'react';
/**
 * High-performance rich-text rendering shell managing syntax highlighted text presentations parsing raw code blocks.
 *
 * @param props - Unified mapping resolving presentation versus active edit inputs.
 *
 * @return Instanced CodeMirror window evaluating code chunks mapped dynamically against site theme constraints.
 *
 * @remarks Facilitates explicit fallbacks during hydration avoiding layout shifts natively.
 */
export declare function CodeBlock(props: {
    className?: string;
    code?: unknown;
    docsSource?: boolean;
    language: string;
    source?: string;
    tone: 'edit';
    placeholder?: string;
    expandAll?: boolean;
    fullHeight?: boolean;
    languageEditable?: boolean;
    readOnly?: boolean;
    onCodeChange?: (code: string) => void;
    onCommit?: (code: string, language: string) => void;
    onLanguageChange?: (language: string, code: string) => void;
} | {
    className?: string;
    code?: unknown;
    docsSource?: boolean;
    language: string;
    source?: string;
    tone: 'view';
    placeholder?: string;
}): JSX.Element;
//# sourceMappingURL=_CodeBlock.d.ts.map