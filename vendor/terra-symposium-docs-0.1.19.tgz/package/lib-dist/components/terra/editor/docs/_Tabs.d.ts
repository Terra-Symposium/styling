/** Docs tabs and accordion renderer with view and edit modes. */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Union of the docs tabs and accordion block shapes. */
type SectionsBlock = DocsBlock<'tabs'> | DocsBlock<'accordion'>;
/** Adapts Portable Text's block-object contract to the sections renderer. */
/**
 * Renders the renderSections component.
 *
 * @param props - Portable Text renderer attributes, nested children, section node, path, and read-only mode.
 * @returns The sections renderer in editable or read-only mode.
 */
export declare function renderSections({ attributes: attrs, children, node, path, readOnly, }: PortableTextBlockRendererProps<SectionsBlock>): React.JSX.Element;
export {};
//# sourceMappingURL=_Tabs.d.ts.map