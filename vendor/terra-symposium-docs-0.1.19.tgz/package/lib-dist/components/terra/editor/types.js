// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/types.ts
 * Shared Terra content and Portable Text renderer contracts.
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// DATA
import { DOCS_BLOCK_SCHEMAS, PROBLEM_BLOCK_TYPES } from '../runtime/types.js';
//# sourceMappingURL=types.js.map