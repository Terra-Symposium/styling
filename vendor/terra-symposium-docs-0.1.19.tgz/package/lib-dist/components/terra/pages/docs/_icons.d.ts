/**
 * astro/src/pages/docs/_icons.ts
 * Shared Docs block icon registry.
 */
export declare const DOCS_BLOCK_ICONS: {
    readonly accordion: import("@carbon/icons-react").CarbonIconType;
    readonly callout: import("@carbon/icons-react").CarbonIconType;
    readonly code: import("@carbon/icons-react").CarbonIconType;
    readonly docImage: import("@carbon/icons-react").CarbonIconType;
    readonly embed: import("@carbon/icons-react").CarbonIconType;
    readonly heading: import("@carbon/icons-react").CarbonIconType;
    readonly math: import("@carbon/icons-react").CarbonIconType;
    readonly nodes: import("@carbon/icons-react").CarbonIconType;
    readonly paragraph: import("@carbon/icons-react").CarbonIconType;
    readonly raw: import("@carbon/icons-react").CarbonIconType;
    readonly table: import("@carbon/icons-react").CarbonIconType;
    readonly tabs: import("@carbon/icons-react").CarbonIconType;
    readonly tsDocs: import("@carbon/icons-react").CarbonIconType;
};
//# sourceMappingURL=_icons.d.ts.map