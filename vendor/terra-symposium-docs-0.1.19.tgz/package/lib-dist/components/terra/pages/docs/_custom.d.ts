import type { DocsCustomBlock } from '../../../../lib/host.js';
/** Mutated in place by a host before the workspace renders. */
export declare const components: DocsCustomBlock[];
export declare function setDocsCustomComponents(next: DocsCustomBlock[]): void;
//# sourceMappingURL=_custom.d.ts.map