import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/pages/docs/_export-dialog.tsx
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// API
import { useState } from 'react';
// COMPONENTS
import { Button } from '@terra-symposium/styling/ui/terra-original';
import { Checkbox } from '@terra-symposium/styling/ui/terra-original';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, } from '@terra-symposium/styling/ui/terra-original';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Label } from '@terra-symposium/styling/ui/terra-original';
import { Progress } from '@terra-symposium/styling/ui/terra-original';
/*//////////////////////////////////////////////////
CLASSES
//////////////////////////////////////////////////*/
const TEXT_SM_FONT_MEDIUM_TEXT_PRIMARY_12_CLASS = 'text-sm font-medium text-primary-12';
const FLEX_ITEMS_CENTER_SPACE_X_2_CLASS = 'flex items-center space-x-2';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/**
 * Renders the export dialog component.
 *
 * @param props - Export target, document data, and dialog state callbacks.
 *
 * @return Dialog for exporting documentation content.
 */
export function ExportDialog({ target: tgt, setTarget: setTgt, disabled, onExport, }) {
    const [opts, setOpts] = useState({
        flatten: false,
        format: 'raw',
        filters: { pages: true, pdfs: true, images: true, youtube: true, tsdocs: true, other: true },
        merges: { pages: false, pdfs: false, images: false, youtube: false, tsdocs: false },
    });
    const [busy, setBusy] = useState(false);
    const [progress, setProgress] = useState(0);
    if (!tgt)
        return null;
    const content = [
        { key: 'pages', label: 'Text' },
        { key: 'pdfs', label: 'PDFs' },
        { key: 'images', label: 'Images' },
        { key: 'youtube', label: 'YouTube Transcripts' },
        { key: 'tsdocs', label: 'TSDocs' },
        { key: 'other', label: 'Other' },
    ];
    return (_jsx(ErrorBoundary, { name: "ExportDialog", children: _jsx(Dialog, { open: true, onOpenChange: (o) => !busy && !o && setTgt(null), children: _jsxs(DialogContent, { className: "text-foreground bg-background dark:bg-zinc-950 dark:text-zinc-50", size: "sm", "aria-busy": busy, children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { children: ["Export ", tgt.title] }), _jsx(DialogDescription, { children: "Select the content and formats to include in your export." })] }), _jsxs("div", { className: "space-y-6 py-4", children: [_jsxs("div", { className: "space-y-3", role: "group", "aria-labelledby": "export-include-content-heading", children: [_jsx("h4", { id: "export-include-content-heading", className: TEXT_SM_FONT_MEDIUM_TEXT_PRIMARY_12_CLASS, children: "Include Content" }), _jsx("div", { className: "grid grid-cols-2 gap-3", children: content.map((i) => (_jsxs("div", { className: FLEX_ITEMS_CENTER_SPACE_X_2_CLASS, children: [_jsx(Checkbox, { id: `filter-${i.key}`, checked: opts.filters[i.key], disabled: disabled || busy, onCheckedChange: (c) => {
                                                        setOpts((p) => ({ ...p, filters: { ...p.filters, [i.key]: !!c } }));
                                                    } }), _jsx(Label, { htmlFor: `filter-${i.key}`, children: i.label })] }, i.key))) })] }), _jsxs("div", { className: "space-y-3", role: "group", "aria-labelledby": "export-merge-heading", children: [_jsx("h4", { id: "export-merge-heading", className: TEXT_SM_FONT_MEDIUM_TEXT_PRIMARY_12_CLASS, children: "Merge" }), _jsx("div", { className: "grid grid-cols-2 gap-3", children: content
                                            .filter((i) => i.key !== 'other')
                                            .map((i) => (_jsxs("div", { className: FLEX_ITEMS_CENTER_SPACE_X_2_CLASS, children: [_jsx(Checkbox, { id: `merge-${i.key}`, checked: opts.merges[i.key] && opts.filters[i.key], disabled: disabled || busy || !opts.filters[i.key], onCheckedChange: (c) => {
                                                        setOpts((p) => ({ ...p, merges: { ...p.merges, [i.key]: !!c } }));
                                                    } }), _jsx(Label, { htmlFor: `merge-${i.key}`, className: !opts.filters[i.key] ? 'opacity-50' : '', children: i.label })] }, i.key))) })] }), _jsxs("div", { className: "space-y-3", role: "group", "aria-labelledby": "export-processing-heading", children: [_jsx("h4", { id: "export-processing-heading", className: TEXT_SM_FONT_MEDIUM_TEXT_PRIMARY_12_CLASS, children: "Processing Options" }), _jsxs("div", { className: "flex flex-col gap-3", children: [_jsxs("div", { className: FLEX_ITEMS_CENTER_SPACE_X_2_CLASS, children: [_jsx(Checkbox, { id: "opt-flatten", checked: opts.flatten, disabled: disabled || busy, onCheckedChange: (c) => {
                                                            setOpts((p) => ({ ...p, flatten: !!c }));
                                                        } }), _jsx(Label, { htmlFor: "opt-flatten", children: "Flatten folder structure" })] }), _jsxs("div", { className: FLEX_ITEMS_CENTER_SPACE_X_2_CLASS, children: [_jsx(Checkbox, { id: "opt-format", checked: opts.format === 'pdf', disabled: disabled || busy || !opts.filters.pages, onCheckedChange: (c) => {
                                                            setOpts((p) => ({ ...p, format: c ? 'pdf' : 'raw' }));
                                                        } }), _jsx(Label, { htmlFor: "opt-format", children: "Convert Pages to PDF" })] })] })] })] }), _jsx(DialogFooter, { children: busy ? (_jsxs("div", { className: "flex w-full items-center gap-4", role: "status", "aria-live": "polite", children: [_jsx(Progress, { value: progress, className: "h-2 flex-1", "aria-label": `Exporting ${tgt.title} progress`, "aria-valuetext": `${progress}%` }), _jsxs("span", { className: "font-mono text-sm", children: [progress, "%"] })] })) : (_jsxs(_Fragment, { children: [_jsx(Button, { variant: "ghost", onClick: () => {
                                        setTgt(null);
                                    }, children: "Cancel" }), _jsx(Button, { onClick: () => {
                                        void (async () => {
                                            setBusy(true);
                                            setProgress(0);
                                            try {
                                                await onExport(tgt, opts, setProgress);
                                                setTgt(null);
                                            }
                                            finally {
                                                setBusy(false);
                                            }
                                        })();
                                    }, disabled: !Object.values(opts.filters).some(Boolean), children: "Download ZIP" })] })) })] }) }) }));
}
//# sourceMappingURL=_export-dialog.js.map