/**
 * astro/src/pages/docs/_helpers.ts
 * Shared Docs state, browser coordination, and pure helpers used by multiple Docs surfaces.
 * Folder boundary: cross-surface contracts only; page composition, sidebar UI, editor lifecycle, and visual blocks remain in their owners.
 */
import { getHue } from '@terra-symposium/styling';
import type { AttchType, Transition } from '../../runtime/types.js';
import type { DocBody } from '../../runtime/types.js';
import type { EditorSel, Mode, Tree as TreeType } from '../../runtime/types.js';
import type { EditorView } from '@codemirror/view';
export declare const ASIDES: string[];
export declare const document: Document;
/**
 * Handles sanitize name.
 *
 * @param name - Document name used to construct the canonical path.
 */
export declare const sanitizeName: (name: string) => string;
/**
 * Handles is index file.
 *
 * @param path - Docs path to normalize into a route-safe identifier.
 */
export declare const isIndexFile: (path: string) => boolean;
/**
 * Subscribes a React component to an external store and returns its current snapshot.
 *
 * @param store - External store that exposes the current value and a subscription function for change notifications.
 *
 * @return The latest value exposed by the store, kept in sync with its notifications.
 */
export declare function useAtom<Value>(store: {
    get(): Value;
    subscribe(listener: (val: Value) => void): () => void;
}): Value;
/**
 * Executes an async action safely behind a circuit breaker and transition lock.
 *
 * @param action - Async action executed by the guarded operation.
 * @param fallbackErr - Error value returned when the action cannot complete.
 * @param onStart - Optional callback invoked before the action begins.
 * @param onEnd - Optional callback invoked after the action settles.
 */
export declare const runMutation: (action: () => Promise<void>, fallbackErr: string, onStart?: () => void, onEnd?: () => void) => Promise<void>;
/**
 * Handles get hue.
 *
 * @param title - Label displayed for the generated colour group.
 * @param hue - Base hue used to derive the colour group.
 */
export { getHue };
/**
 * Handles get stable key.
 *
 * @param node - Docs tree node whose route should be resolved.
 */
export declare const getStableKey: (node: TreeType) => string;
/**
 * Uploads an asset in bounded chunks and reports progress while the server assembles it.
 *
 * @param file - Browser file to upload.
 * @param dPath - Destination Docs path that owns the uploaded asset.
 * @param opts - Optional image transforms, preview destination, and per-chunk progress callback.
 *
 * @return The saved asset path or URL and any available compression or filename metadata.
 */
export declare function uploadAssetChunked(file: File, dPath: string, opts?: {
    resize?: boolean;
    grayscale?: boolean;
    previewAssetPath?: string;
    onProgress?: (data: {
        bytes: number;
        currentChunk: number;
        totalChunks: number;
        message?: string;
    }) => void;
}): Promise<{
    path?: string;
    src?: string;
    compressedSize?: number;
    name?: string;
}>;
/**
 * Handles download.
 *
 * @param filename - Filename input supplied to download's operation.
 * @param content - Content input supplied to download's operation.
 * @param type - Type input supplied to download's operation.
 */
export declare function download(filename: string, content: string | ArrayBuffer | Blob, type?: string): void;
/**
 * Reads the browser selection when it is a collapsed caret, such as the Docs editor insertion point.
 *
 * @return The active collapsed range, or `null` when there is no browser selection or the selection spans content.
 */
export declare function getCollapsedRange(): Range | null;
/**
 * Captures child-node indexes from a root node to a target so the target can be found after DOM updates.
 *
 * @param root - DOM node whose child tree defines the path origin.
 * @param tgt - Descendant node to locate, or `null` when no selection node exists.
 *
 * @return The sequence of child indexes from the root, or `null` when the target is not inside it.
 */
export declare function captureNodePath(root: Node, tgt: Node | null): number[] | null;
/**
 * Converts a DOM text position into its character offset within the editor's complete text flow.
 *
 * @param root - Editor element whose text nodes define the linear text flow.
 * @param node - Selected DOM node whose position should be measured.
 * @param offset - Character offset within a text node or child index within an element node.
 *
 * @return The character offset from the beginning of the editor, or `null` if the node is absent or outside it.
 */
export declare function captureLinearOffset(root: HTMLElement, node: Node | null, offset?: number): number | null;
/**
 * Finds the DOM caret range at a character offset in the editor's text flow.
 *
 * @param root - Editor element whose text nodes should be traversed.
 * @param i - Character offset from the start of the editor.
 *
 * @return A collapsed range at the requested offset, or `null` for an invalid or out-of-range offset.
 */
export declare function resolveLinearOffset(root: HTMLElement, i?: number): Range | null;
/**
 * Handles paste md.
 *
 * @param insert - Insert input supplied to paste md's operation.
 * @param md - Md input supplied to paste md's operation.
 * @param selection - Selection input supplied to paste md's operation.
 */
export declare function pasteMd(insert: (md: string, rootEnd?: boolean, selection?: EditorSel | null) => void, md: string, selection?: EditorSel | null): void;
/**
 * Adds an import statement when equivalent syntax is not already present in the source text.
 *
 * @param md - Markdown or source text that should receive the import.
 * @param statement - Complete import statement to add when no matching import exists.
 *
 * @return The original text when the import is already present, otherwise the text with the import prepended.
 */
export declare function withImport(md: string, statement: string): string;
/**
 * Locates the CodeMirror view in the code block that currently has keyboard focus.
 *
 * @return The mounted editor view, or `null` during SSR or when the editor is not mounted.
 */
export declare function codeViewOf(): EditorView | null;
/**
 * Converts raw HTML into structured md, maintaining basic formatting constraints.
 *
 * @param html - Raw HTML to convert into the editor's Markdown representation.
 *
 * @return Markdown text with supported block and inline formatting preserved.
 */
export declare function htmlToMd(html: string): string;
/**
 * Shared attachment types accepted by the docs editor.
 *
 * @returns supported attachment type literals.
 *
 * @remarks These types drive both filtering and export behavior.
 */
export declare const ATTCH_TYPES: readonly ["document", "image", "youtube", "website", "tsdocs", "other"];
/**
 * Persistent attachment filter state.
 *
 * @returns An atom holding the selected attachment types.
 *
 * @remarks The filter defaults to showing all supported types.
 */
export declare const $attachmentFilter: import("nanostores").PreinitializedWritableAtom<AttchType[]> & object;
/**
 * Current docs editor mode.
 *
 * @returns A persisted mode atom.
 *
 * @remarks The mode is restored from local storage so the editor reopens in the same state.
 */
export declare const $mode: import("nanostores").PreinitializedWritableAtom<Mode> & object;
/** Shares the active leaf title across Docs surfaces. */
export declare const $leafTitle: import("nanostores").PreinitializedWritableAtom<{
    path: string;
    title: string;
} | null> & object;
/**
 * Global transition flag for docs navigation and mutations.
 *
 * @returns A boolean atom.
 *
 * @remarks This lets the UI disable inputs while a transition is active.
 */
export declare const $transition: import("nanostores").PreinitializedWritableAtom<boolean> & object;
/**
 * Current toolbar state.
 *
 * @returns A nullable toolbar atom.
 *
 * @remarks The toolbar is controlled centrally so overlays can share the same focus state.
 */
export declare const $toolbar: import("nanostores").PreinitializedWritableAtom<any> & object;
/**
 * Hydration counter for docs editor widgets.
 *
 * @returns A numeric atom tracking hydration depth.
 *
 * @remarks This is used to delay interactions until the editor tree is ready.
 */
export declare const $hydrating: import("nanostores").PreinitializedWritableAtom<number> & object;
/**
 * Surface readiness state for docs editing.
 *
 * @returns A nullable mode atom.
 *
 * @remarks The value flips once the interactive surface is available.
 */
export declare const $surfaceReady: import("nanostores").PreinitializedWritableAtom<Mode | null> & object;
export declare const $editReadyPath: import("nanostores").PreinitializedWritableAtom<string | null> & object;
/** Shared cursor state so toolbar focus can preserve the last insertion point visibly. */
export declare const $cursor: import("nanostores").PreinitializedWritableAtom<any> & object;
/** Persisted caret snapshot used for the simulated cursor overlay when focus leaves the editor. */
export declare const $cursorGhost: import("nanostores").PreinitializedWritableAtom<any> & object;
/** Linear caret bookmark used to simulate the visible cursor without relying on DOM focus. */
export declare const $cursorTrack: import("nanostores").PreinitializedWritableAtom<(Pick<any, "box" | "collapsed" | "visible"> & {
    anchor: number;
    focus: number;
    range: [number, number];
}) | null> & object;
/**
 * Cursor position snapshot for the docs editor.
 *
 * @returns A nullable cursor atom.
 *
 * @remarks This duplicates the visible cursor state for consumers that need direct position access.
 */
export declare const $cursorPosition: import("nanostores").PreinitializedWritableAtom<any> & object;
/**
 * Unsaved docs draft flags.
 *
 * @returns A map store keyed by document id.
 *
 * @remarks This store only tracks presence, not draft content.
 */
export declare const $unsavedDrafts: import("nanostores").PreinitializedMapStore<Record<string, boolean>> & object;
/**
 * In-memory docs draft cache.
 *
 * @returns A map of draft payloads and metadata.
 *
 * @remarks This cache is process-local and intentionally not persisted.
 */
export declare const memoryDrafts: Map<string, {
    source: string;
    draft: unknown;
    metadata: unknown;
}>;
/**
 * Sidebar visibility state for the docs editor.
 *
 * @returns A persisted boolean atom.
 *
 * @remarks The default keeps the sidebar open for discoverability.
 */
export declare const $sidebar: import("nanostores").PreinitializedWritableAtom<boolean> & object;
/**
 * Shared transition store for docs UI coordination.
 *
 * @returns transition store object.
 *
 * @remarks This is kept as a plain object so listeners can subscribe without extra abstractions.
 */
export declare const transitionStore: {
    transition: Transition;
    restore: (() => void) | null;
    listeners: Set<() => void>;
};
/**
 * Sets the active docs transition state.
 *
 * @param transition - Next transition state.
 *
 * @remarks The boolean store mirrors the non-idle state for simpler UI consumers.
 */
export declare function setTransition(transition: Transition): void;
/**
 * Clears the active docs transition state.
 *
 *
 * @remarks Idle is the only state that leaves the transition flag unset.
 */
export declare function clearTransition(): void;
/**
 * Subscribes to the current docs transition state.
 *
 * @return use Transition State.
 *
 * @remarks This is used by components that need to react to local mutation states.
 */
export declare function useTransitionState(): Transition;
/**
 * Shared editor transition context.
 *
 * @returns transition context object.
 *
 * @remarks The provider keeps layout and loading overlays in sync.
 */
export declare const TransitionCtx: import("react").Context<{
    setSourceReady: (ready: boolean) => void;
    setLoading: (loading: boolean) => void;
} | null>;
/**
 * Context for docs edit state.
 *
 * @returns edit state context object.
 *
 * @remarks The context carries the current editable document state through the editor tree.
 */
export declare const EditStateCtx: import("react").Context<{
    busy: import("../../runtime/types.js").EditorState["busy"];
    code: string;
    draft: import("../../runtime/types.js").Draft;
    dirty: boolean;
    loaded?: boolean;
    mark?: () => void;
    references?: import("react").MutableRefObject<import("../../runtime/types.js").EditorRefs>;
    setSrc?: (val: string) => void;
    source?: string;
    state?: import("../../runtime/types.js").EditorState;
    save: (code?: string, opts?: {
        force?: boolean;
        format?: boolean;
    }) => void;
    setCode: (val: string) => void;
    update: (patch: Partial<import("../../runtime/types.js").Draft>) => void;
} | null>;
/**
 * Context for the docs editor surface.
 *
 * @returns surface context object.
 *
 * @remarks This lets nested components reach the active editor surface without prop drilling.
 */
export declare const EditorSurfaceCtx: import("react").Context<any>;
/**
 * Handles extract all node ids.
 *
 * @param nodes - Graph nodes rendered and updated by extract all node ids.
 *
 * @return All unique ids discovered in the tree.
 *
 * @remarks Collects every node identifier from a tree of docs entries.
 */
export declare function extractAllNodeIds(nodes: TreeType[]): string[];
export declare const $editorMounts: import("nanostores").PreinitializedWritableAtom<{
    expected: string[];
    mounted: string[];
    path: string | null;
}> & object;
/**
 * Handles reset editor mounts.
 *
 * @param path - Source or route path resolved for reset editor mounts.
 * @param expected - Expected input supplied to reset editor mounts's operation.
 */
export declare function resetEditorMounts(path: string | undefined, expected: string[]): void;
/**
 * Handles set editor mount.
 *
 * @param path - Source or route path resolved for set editor mount.
 * @param reporter - Reporter input supplied to set editor mount's operation.
 * @param mounted - Mounted input supplied to set editor mount's operation.
 * @param kind - Content kind that selects set editor mount's renderer.
 */
export declare function setEditorMount(path: string | undefined, reporter: string | undefined, mounted: boolean, kind?: string): void;
/**
 * Handles keep deep path.
 *
 * @param current - Current value before the update.
 * @param next - Proposed value to compare with the current value.
 */
export declare const keepDeepPath: (curr: string, n: string) => string;
/**
 * Handles is doc body.
 *
 * @param value - Value whose display label should be derived.
 */
export declare const isDocBody: (val: unknown) => val is DocBody;
/**
 * Determines which Docs toolbar block is active at the current editor selection.
 *
 * @param el - Focused element inside the active Docs editor.
 * @param vals - Supported block kinds that may be returned for custom content.
 *
 * @return The active block kind, or `null` when the selection is outside a supported block.
 */
export declare function toolbarFocusValue(el: Element, vals: readonly string[]): string | null;
//# sourceMappingURL=_helpers.d.ts.map