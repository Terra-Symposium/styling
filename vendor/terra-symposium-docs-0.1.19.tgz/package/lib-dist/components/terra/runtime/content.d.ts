/**
 * astro/src/actions/docs/content.ts
 * Shared helpers for normalizing and serializing docs content versions, syntax, and tables.
 */
import type { DocBody } from './types.js';
/** Portable Text object types accepted by problem authoring. */
export declare const PROBLEM_BLOCK_TYPES: readonly ["hint", "headline", "nodes", "entity", "definition", "countryReference", "notes", "photo", "audio", "video", "choicesReference", "question", "prompts", "timer", "table", "map", "tabs", "accordion"];
/**
 * Handles docs editor mount ids.
 *
 * @param source - Source text containing the Docs blocks to parse.
 */
export declare const docsEditorMountIds: (src: string) => string[];
/**
 * Rewrites the supported docs block markers into their JSX wrapper forms.
 *
 * @param md - Markdown or MDX source to normalize.
 *
 * @return Source where supported block markers have been rewritten to their JSX wrappers.
 *
 * @remarks
 * Only the supported block syntaxes are rewritten; everything else is preserved.
 */
export declare function toBlockJsx(md: string): string;
/**
 * Restores the custom docs JSX wrappers back to the markdown block syntax they came from.
 *
 * @param jsx - Canonical JSX source to restore.
 *
 * @return Markdown where supported docs JSX wrappers have been converted back to block syntax.
 *
 * @remarks
 * This is the inverse of `toBlockJsx` for the supported docs block shapes.
 */
export declare function fromBlockJsx(jsx: string): string;
/**
 * Converts any code payload into a printable string before it is written into docs markup.
 *
 * @param val - Any code-like value to stringify.
 *
 * @return Printable code string used by the markdown and MDX serializers.
 *
 * @remarks
 * Prefers compact primitives and pretty-prints structured values.
 */
export declare function stringifyCodeValue(val: unknown): string;
/**
 * Serializes fenced code into the canonical `<Code>` JSX used by docs content.
 *
 * @param lang - Code fence language label.
 * @param val - Raw code text.
 *
 * @return Canonical `Code` JSX for the code block.
 *
 * @remarks
 * The code payload is HTML-escaped so it can round-trip through MDX safely.
 */
export declare function codeJsx(lang: string | undefined, val: string): string;
/**
 * Handles code src jsx.
 *
 * @param lang - Code language label used for the generated code block.
 * @param src - Source code text to wrap in the code block.
 */
export declare const codeSrcJsx: (lang: string | undefined, src: string) => string;
/**
 * Normalizes markdown fences into the canonical Code JSX form.
 *
 * @param src - Markdown, fenced code, or legacy HTML source.
 *
 * @return Canonical `Code` JSX where code blocks were found.
 *
 * @remarks
 * The function leaves unrelated prose untouched so callers can run it on whole documents.
 */
export declare function toCodeJsx(src: string): string;
/**
 * Renders a markdown pipe table into HTML when the row widths and separator row are valid.
 *
 * @param md - Table markdown to render.
 * @param renderCell - Cell renderer used for each value.
 *
 * @returns HTML table markup when the input is a valid pipe table, otherwise `null`.
 *
 * @remarks
 * Callers can supply a custom cell renderer to preserve nested markdown or JSX.
 */
export declare const mdTableToHtml: (md: string, renderCell?: (val: string) => string) => string | null;
/**
 * Handles strip nested anchors.
 *
 * @param val - Table cell markup to sanitize before it is embedded in a Docs table.
 */
export declare const stripNestedAnchors: (val: string) => string;
/**
 * Handles sanitize table html.
 *
 * @param val - Table markup whose inline styles should be removed.
 */
export declare const sanitizeTableHtml: (val: string) => string;
/** Identifies complete canonical HTML table markup. */
export declare const TABLE_TAG: RegExp;
/**
 * Normalizes block spacing in serialized docs source.
 *
 * @param src - Markdown or MDX source to normalize.
 *
 * @returns Source with headings and block delimiters separated onto their own lines.
 */
export declare const normDocsSpacing: (src: string) => string;
/**
 * Stringifies the Doc Content Body for the docs.
 *
 * @param body - Structured docs content to serialize.
 *
 * @returns Markdown or MDX source for the provided body, or an empty string for empty input.
 *
 * @remarks
 * Empty bodies return an empty string so callers can short-circuit easily.
 */
export declare const stringifyDocBody: (body: DocBody | null | undefined) => string;
/**
 * Stringifies the Editor Content Body for the docs.
 *
 * @param body - Structured docs content to serialize.
 *
 * @returns MDX source that MDXEditor can reopen without delimiter-rewrite drift.
 *
 * @remarks
 * Accordions, tabs, and tables are emitted as explicit JSX so nested HTML never relies on regex block rewriting.
 */
export declare const stringifyEditorContentBody: (body: DocBody | null | undefined) => string;
/**
 * Handles stringify problem editor content body.
 *
 * @param body - Problem editor body to serialize into Markdown source.
 */
export declare const stringifyProblemEditorContentBody: (body: DocBody | null | undefined) => string;
/**
 * Serializes the current leaf content payload without inspecting ver history.
 *
 * @param content - Direct `leaf.content` value or a compatibility wrapper around it.
 *
 * @returns Markdown or MDX for the active document body only.
 *
 * @remarks
 * This is the preferred live-doc read path now that leaf content is stored directly.
 */
export declare const currDocMd: (content: unknown) => string;
//# sourceMappingURL=content.d.ts.map