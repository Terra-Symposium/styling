import type { Tree } from './types.js';
export declare const FILES: {
    readonly index: RegExp;
    readonly markdown: RegExp;
};
export declare const REORDER: {
    readonly active: "bg-primary-3 text-primary-12 ring-1 ring-primary-7";
    readonly after: "after:absolute after:inset-x-2 after:bottom-0 after:h-0.5 after:rounded-full after:bg-primary-9";
    readonly before: "before:absolute before:inset-x-2 before:top-0 before:h-0.5 before:rounded-full before:bg-primary-9";
    readonly handle: "size-6 shrink-0 cursor-grab transition-opacity focus-visible:opacity-100 active:cursor-grabbing";
};
export declare const IMAGE_TYPES: Record<string, string>;
export declare const MIME: Record<string, string>;
export declare const TESTIMONIALS_EXPORT = "";
export declare const componentExport: (name: string) => string;
export declare function docsRootPath(): string;
export declare function docsPath(path?: string): string;
export declare function isDocsPath(path: string): boolean;
export declare function toPaths(nodes: Tree[]): string[];
export declare function isEndpointVal(value: string): boolean;
export declare function toNodeLabel(title: string): string;
export declare function dirname(path: string): string;
export declare function bName(path: string, ext?: string): string;
export declare const cTitle: (title?: string) => string;
export declare const fmtNodeTitle: (value: string) => string;
export declare const toPascal: (value: string) => string;
export declare function buildRoute(sectionId: string, groupId?: string, leafId?: string): string;
export declare function parseRoute(value: string): {
    sectionId: string;
    groupId?: string;
    leafId?: string;
    targetId: string;
    pathname: string;
};
//# sourceMappingURL=shared.d.ts.map