import { Component } from 'react';
import type { ErrorInfo, JSX, ReactNode } from 'react';
export declare class ErrorBoundary extends Component<{
    children?: ReactNode;
    name?: string;
    fallback?: (error: Error) => ReactNode;
    resetKey?: unknown;
}, {
    error: Error | null;
}> {
    state: {
        error: Error | null;
    };
    static getDerivedStateFromError(error: Error): {
        error: Error;
    };
    componentDidCatch(_error: Error, _info: ErrorInfo): void;
    render(): string | number | bigint | boolean | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | JSX.Element | null | undefined;
}
export declare function Empty({ title, description, }: {
    title?: string;
    description?: string;
}): JSX.Element;
export declare const IMG_RESPONSIVE = "max-w-full object-contain";
export default function User({ user, }: {
    user?: {
        name?: string;
        email?: string;
    } | null;
}): JSX.Element;
//# sourceMappingURL=ui.d.ts.map