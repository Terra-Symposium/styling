let invoke = async (operation) => ({
    error: new Error(`Docs host action is not configured: ${operation}`),
});
export function configureDocsActionProxy(handler) {
    invoke = handler;
}
function action(path) {
    const callable = (...args) => invoke(path, args[0]);
    return new Proxy(callable, {
        get(_target, key) {
            if (typeof key !== 'string')
                return undefined;
            return action(path ? `${path}.${key}` : key);
        },
    });
}
/** Internal compatibility bridge for the original UI's nested host-action calls. */
export const actions = action('');
//# sourceMappingURL=action-proxy.js.map