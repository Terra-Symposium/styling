import { cn as stylingCn } from '@terra-symposium/styling/ui';
export declare const cn: typeof stylingCn;
export declare function isDevOrigin(value: string | URL): boolean;
export declare const isRec: (value: unknown) => value is Record<string, any>;
export declare const isString: (value: unknown) => value is string;
export declare const isNumber: (value: unknown) => value is number;
export declare const validateType: (types: readonly string[], value: unknown) => boolean;
export declare const warn: (tag: string, message: string, detail?: unknown) => void;
export declare const error: (tag: string, message: string, detail?: unknown) => void;
export declare const errorLog: (tag: string, message: string, detail?: unknown) => void;
export declare const createTrace: (scope: string, enabled: boolean) => (event: string, detail?: unknown) => void;
export declare const notify: ({ error: reason, fallback }: {
    error: unknown;
    fallback: string;
}) => void;
export declare const hash: (value: string) => number;
export declare const canonicalId: (value: string) => string;
export declare const normArcGraph: <T>(graph: T) => T;
export declare function resolvedEdges(graph: any): any[];
export declare function setDocumentTitle(title: string): void;
export declare const isDarkMode: () => boolean;
export declare const getImg: (id: string, width?: number) => {
    url: () => string;
};
//# sourceMappingURL=runtime.d.ts.map