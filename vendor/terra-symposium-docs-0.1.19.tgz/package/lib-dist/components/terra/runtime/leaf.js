import { stringifyDocBody } from './content.js';
export const toPortableBody = (value) => Array.isArray(value) ? value : [];
export const currLeafBody = (value) => {
    if (Array.isArray(value))
        return toPortableBody(value);
    if (value && typeof value === 'object') {
        const item = value;
        return toPortableBody(Array.isArray(item.main) ? item.main : item.content);
    }
    return [];
};
export const currLeafSrc = (value) => typeof value === 'string' ? value : stringifyDocBody(currLeafBody(value));
//# sourceMappingURL=leaf.js.map