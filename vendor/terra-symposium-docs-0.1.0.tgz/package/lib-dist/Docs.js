import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { EditorProvider, PortableTextEditable, useEditor } from '@portabletext/editor';
import { EventListenerPlugin } from '@portabletext/editor/plugins';
import { useEffect } from 'react';
import { Toolbar } from './_Toolbar.js';
import { safeLink, schema } from './schema.js';
/** A minimal standalone version of TerraContentEditor's Portable Text surface. */
export function Docs(props) {
    return (_jsx("div", { className: ['terra-docs', props.className].filter(Boolean).join(' '), children: _jsx(EditorProvider, { initialConfig: {
                schemaDefinition: schema,
                initialValue: props.value,
                readOnly: props.mode === 'view',
            }, children: _jsx(DocsSurface, { ...props }) }) }));
}
function DocsSurface(props) {
    const editor = useEditor();
    // initialConfig is read once; subsequent host values and mode changes need explicit updates.
    useEffect(() => {
        editor.send({ type: 'update value', value: props.value });
    }, [editor, props.value]);
    useEffect(() => {
        editor.send({ type: 'update readOnly', readOnly: props.mode === 'view' });
    }, [editor, props.mode]);
    return (_jsxs(_Fragment, { children: [_jsx(EventListenerPlugin, { on: (event) => {
                    if (event.type === 'mutation' && props.mode === 'edit') {
                        props.onChange(event.value ?? []);
                    }
                } }), props.mode === 'edit' && _jsx(Toolbar, {}), _jsx(PortableTextEditable, { "aria-label": props.mode === 'edit' ? 'Document editor' : 'Document viewer', "aria-readonly": props.mode === 'view', contentEditable: props.mode === 'edit', className: "terra-docs-content", renderStyle: ({ children, schemaType }) => {
                    if (schemaType.value === 'h2')
                        return _jsx("h2", { children: children });
                    if (schemaType.value === 'h3')
                        return _jsx("h3", { children: children });
                    if (schemaType.value === 'h4')
                        return _jsx("h4", { children: children });
                    if (schemaType.value === 'h5')
                        return _jsx("h5", { children: children });
                    if (schemaType.value === 'h6')
                        return _jsx("h6", { children: children });
                    if (schemaType.value === 'blockquote')
                        return _jsx("blockquote", { children: children });
                    return _jsx("p", { children: children });
                }, renderDecorator: ({ children, value }) => {
                    if (value === 'strong')
                        return _jsx("strong", { children: children });
                    if (value === 'em')
                        return _jsx("em", { children: children });
                    if (value === 'underline')
                        return _jsx("u", { children: children });
                    if (value === 'strike-through')
                        return _jsx("s", { children: children });
                    return _jsx(_Fragment, { children: children });
                }, renderAnnotation: ({ children, value }) => {
                    const href = safeLink(value.href);
                    return href ? _jsx("a", { href: href, children: children }) : _jsx(_Fragment, { children: children });
                } })] }));
}
//# sourceMappingURL=Docs.js.map