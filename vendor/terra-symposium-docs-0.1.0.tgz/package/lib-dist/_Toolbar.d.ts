import type { JSX } from 'react';
/** Terra's style dropdown and Carbon formatting controls, without website UI dependencies. */
export declare function Toolbar(): JSX.Element;
//# sourceMappingURL=_Toolbar.d.ts.map