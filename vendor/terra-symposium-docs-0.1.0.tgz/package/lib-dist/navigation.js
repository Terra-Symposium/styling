import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export function DocsNavigation({ nodes, currentPath, }) {
    const render = (items) => (_jsx("ul", { className: "terra-docs-nav-list", children: items.map((node, index) => (_jsxs("li", { children: [node.href ? (_jsx("a", { href: node.href, "aria-current": node.href === currentPath ? 'page' : undefined, children: node.title })) : (_jsx("span", { children: node.title })), node.children?.length ? render(node.children) : null] }, `${node.href ?? node.title}-${index}`))) }));
    return (_jsx("nav", { className: "terra-docs-nav", "aria-label": "Documentation", children: render(nodes) }));
}
//# sourceMappingURL=navigation.js.map