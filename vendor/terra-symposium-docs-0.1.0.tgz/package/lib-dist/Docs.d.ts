import type { PortableTextBlock } from '@portabletext/editor';
import type { JSX } from 'react';
/** Portable Text blocks supplied and retained by the host application. */
export type DocsValue = PortableTextBlock[];
/** Selects editing or read-only rendering. */
export type DocsMode = 'edit' | 'view';
/** Controlled content with editing callbacks available only in edit mode. */
export type DocsProps = {
    value: DocsValue;
    className?: string;
} & ({
    mode: 'edit';
    onChange: (value: DocsValue) => void;
} | {
    mode: 'view';
    onChange?: never;
});
/** A minimal standalone version of TerraContentEditor's Portable Text surface. */
export declare function Docs(props: DocsProps): JSX.Element;
//# sourceMappingURL=Docs.d.ts.map