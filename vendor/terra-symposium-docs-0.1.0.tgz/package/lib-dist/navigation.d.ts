import type { JSX } from 'react';
export type DocsNavNode = {
    title: string;
    href?: string;
    children?: DocsNavNode[];
};
export declare function DocsNavigation({ nodes, currentPath, }: {
    nodes: DocsNavNode[];
    currentPath: string;
}): JSX.Element;
//# sourceMappingURL=navigation.d.ts.map